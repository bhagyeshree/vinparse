package com.bhagyeshree.spring.validate.api.service;

import org.springframework.stereotype.Service;

@Service
public class VinService {

}
